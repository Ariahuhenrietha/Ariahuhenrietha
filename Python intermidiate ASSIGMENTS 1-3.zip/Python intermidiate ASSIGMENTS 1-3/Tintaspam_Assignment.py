import os
import zipfile
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.preprocessing import LabelEncoder

# Define paths
titanic_csv_path = r'C:\Users\User\Desktop\Titanic-Dataset.csv'
spam_zip_path = r'C:\Users\User\Desktop\ASSIGNMENTS\archive.zip'
spam_extract_to = r'C:\Users\User\Desktop\ASSIGNMENTS\spam_extracted'

# Function to extract zip files
def extract_zip(zip_path, extract_to):
    print(f"Extracting from: {zip_path}")
    print(f"Extracting to: {extract_to}")
    if not os.path.exists(zip_path):
        print(f"Error: The file {zip_path} does not exist.")
        return
    os.makedirs(extract_to, exist_ok=True)
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_to)
    print(f"Files extracted: {os.listdir(extract_to)}")

# Extract Spam Mails dataset
extract_zip(spam_zip_path, spam_extract_to)

# Load Titanic dataset
if not os.path.exists(titanic_csv_path):
    print(f"Error: The file {titanic_csv_path} does not exist.")
else:
    train_df = pd.read_csv(titanic_csv_path)
    print("Titanic data loaded successfully.")

    # Titanic Data Preprocessing
    train_df['Age'] = train_df['Age'].fillna(train_df['Age'].median())
    train_df['Embarked'] = train_df['Embarked'].fillna(train_df['Embarked'].mode()[0])
    train_df['Sex'] = train_df['Sex'].map({'male': 0, 'female': 1})
    train_df['Embarked'] = train_df['Embarked'].map({'C': 0, 'Q': 1, 'S': 2})

    X_train = train_df[['Pclass', 'Sex', 'Age', 'SibSp', 'Parch', 'Embarked']]
    y_train = train_df['Survived']

    X_train, X_test, y_train, y_test = train_test_split(X_train, y_train, test_size=0.2, random_state=42)

    # Train and evaluate Titanic model
    titanic_model = RandomForestClassifier()
    titanic_model.fit(X_train, y_train)
    y_pred = titanic_model.predict(X_test)
    print('Titanic Model Accuracy:', accuracy_score(y_test, y_pred))

# Load Spam Mails dataset
spam_csv_path = os.path.join(spam_extract_to, 'spam_ham_dataset.csv')
if not os.path.exists(spam_csv_path):
    print(f"Error: The file {spam_csv_path} does not exist.")
else:
    spam_df = pd.read_csv(spam_csv_path, encoding='latin-1')
    print("Spam data loaded successfully.")

    # Inspect columns to find the correct message column name
    print("Columns in spam dataset:", spam_df.columns)

    # Assuming the message column might be named differently
    # Update the column names as per the actual file
    message_column = 'text'  # Replace 'text' with the actual column name if different
    label_column = 'label'    # Replace 'label' with the actual column name if different

    if message_column not in spam_df.columns or label_column not in spam_df.columns:
        print(f"Error: The required columns '{message_column}' or '{label_column}' are not in the dataset.")
    else:
        le = LabelEncoder()
        spam_df[label_column] = le.fit_transform(spam_df[label_column])

        vectorizer = CountVectorizer()
        X_spam = vectorizer.fit_transform(spam_df[message_column])
        y_spam = spam_df[label_column]

        X_train_spam, X_test_spam, y_train_spam, y_test_spam = train_test_split(X_spam, y_spam, test_size=0.2, random_state=42)

        # Train and evaluate Spam Mails model
        spam_model = MultinomialNB()
        spam_model.fit(X_train_spam, y_train_spam)
        y_pred_spam = spam_model.predict(X_test_spam)
        print('Spam Mails Model Accuracy:', accuracy_score(y_test_spam, y_pred_spam))
