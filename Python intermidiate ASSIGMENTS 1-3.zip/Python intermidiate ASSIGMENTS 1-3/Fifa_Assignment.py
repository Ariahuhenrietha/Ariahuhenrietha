import zipfile
import pandas as pd
import os
from datetime import datetime
import matplotlib.pyplot as plt

# Define paths
zip_path = r'C:\Users\User\Desktop\PYTHON PROGRAMS\archive (2).zip'
extract_path = r'C:\Users\User\Desktop\PYTHON PROGRAMS\extracted'

# Extract the ZIP file
with zipfile.ZipFile(zip_path, 'r') as zip_ref:
    zip_ref.extractall(extract_path)

# List files in the directory to find the CSV file
files = os.listdir(extract_path)
print("Files in extracted directory:", files)

# Find the CSV file in the extracted directory
csv_file = [file for file in files if file.endswith('.csv')][0]
csv_path = os.path.join(extract_path, csv_file)

# Load the extracted CSV file
df = pd.read_csv(csv_path, low_memory=False)

# 1. Convert Height and Weight to Numerical Forms
def convert_height(height):
    if pd.isna(height):
        return None
    try:
        feet_inches = height.split("'")
        if len(feet_inches) == 2:
            feet = feet_inches[0].strip()
            inches = feet_inches[1].replace('"', '').strip()
            return int(feet) * 12 + int(inches)
        else:
            return None
    except Exception as e:
        print(f"Error converting height {height}: {e}")
        return None

def convert_weight(weight):
    if pd.isna(weight):
        return None
    try:
        weight = weight.strip()
        if 'lbs' in weight:
            return int(weight.replace('lbs', '').strip())
        elif 'kg' in weight:
            return int(weight.replace('kg', '').strip()) * 2.20462  # Convert kg to lbs
        else:
            return None
    except Exception as e:
        print(f"Error converting weight {weight}: {e}")
        return None

df['Height'] = df['Height'].apply(convert_height)
df['Weight'] = df['Weight'].apply(convert_weight)

# 2. Remove Unnecessary Newline Characters
df = df.apply(lambda x: x.replace('\n', '') if isinstance(x, str) else x)

# 3. Check Players with More Than 10 Years at a Club
df['Joined'] = pd.to_datetime(df['Joined'], errors='coerce')  # Automatically infers format
df['Joined'] = df['Joined'].dt.year
current_year = datetime.now().year
df['Years_at_Club'] = current_year - df['Joined']
long_term_players = df[df['Years_at_Club'] > 10]
print("Players with more than 10 years at a club:")
print(long_term_players[['Name', 'Years_at_Club']])

# 4. Convert 'Value', 'Wage', and 'Release Clause' to Numeric
def convert_money(value):
    if pd.isna(value):
        return None
    value = value.replace('€', '').replace(',', '').strip()
    if 'M' in value:
        return float(value.replace('M', '')) * 1_000_000
    elif 'K' in value:
        return float(value.replace('K', '')) * 1_000
    else:
        return float(value)

df['Value'] = df['Value'].apply(convert_money)
df['Wage'] = df['Wage'].apply(convert_money)
df['Release Clause'] = df['Release Clause'].apply(convert_money)

# 5. Remove 'Star' Characters (if applicable)
def remove_stars(value):
    if pd.isna(value):
        return None
    return float(value.replace('*', '').strip())

# Assuming 'Some_Column' is where stars might be present
# df['Some_Column'] = df['Some_Column'].apply(remove_stars)

# 6. Identify Underpaid but Highly Valuable Players
plt.figure(figsize=(10, 6))
plt.scatter(df['Wage'], df['Value'], alpha=0.5)
plt.xlabel('Wage')
plt.ylabel('Value')
plt.title('Scatter Plot of Wage vs. Value')
plt.show()

# Optionally, filter highly valuable but low-paid players
underpaid_threshold = df['Wage'].quantile(0.25)  # or any value you consider low wage
valuable_threshold = df['Value'].quantile(0.75)  # or any value you consider high value

underpaid_high_value = df[(df['Wage'] < underpaid_threshold) & (df['Value'] > valuable_threshold)]
print("Highly valuable but underpaid players:")
print(underpaid_high_value[['Name', 'Wage', 'Value']])
