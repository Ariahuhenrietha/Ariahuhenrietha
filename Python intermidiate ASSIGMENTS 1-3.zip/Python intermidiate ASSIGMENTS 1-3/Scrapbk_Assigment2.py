import requests
from bs4 import BeautifulSoup

# --- Scrape Books from "All Products" on Books to Scrape - Sandbox ---

def scrape_books(base_url, num_pages):
    books = []
    
    def scrape_page(page_number):
        url = f'{base_url}page-{page_number}.html'
        response = requests.get(url)
        if response.status_code == 200:
            soup = BeautifulSoup(response.text, 'html.parser')
            book_list = soup.find_all('article', class_='product_pod')

            for book in book_list:
                title = book.h3.a['title']
                price = book.find('p', class_='price_color').text
                stock_status = book.find('p', class_='instock availability').text.strip()
                rating = book.p['class'][1]
                details_url = book.h3.a['href']
                
                # Scrape book details from individual book page
                book_response = requests.get(f'http://books.toscrape.com/catalogue/{details_url}')
                book_soup = BeautifulSoup(book_response.text, 'html.parser')
                description = book_soup.find('meta', {'name': 'description'})['content'].strip()
                product_info = book_soup.find('table', class_='table table-striped').text.strip()
                category = book_soup.find('ul', class_='breadcrumb').find_all('a')[2].text

                books.append({
                    'title': title,
                    'price': price,
                    'stock_status': stock_status,
                    'rating': rating,
                    'description': description,
                    'product_info': product_info,
                    'category': category
                })
    
    for page in range(1, num_pages + 1):
        scrape_page(page)
    
    return books

# Base URL for the Books to Scrape site
books_base_url = 'http://books.toscrape.com/catalogue/'
num_pages_books = 5
books_data = scrape_books(books_base_url, num_pages_books)
print("Books Data:", books_data)

# --- Scrape Quote Authors from "Quotes to Scrape" ---

def scrape_authors(base_url, num_pages):
    authors = []
    author_urls = set()  # To keep track of visited author pages

    def scrape_page(page_number):
        url = f'{base_url}{page_number}/'
        response = requests.get(url)
        if response.status_code == 200:
            soup = BeautifulSoup(response.text, 'html.parser')
            quote_list = soup.find_all('div', class_='quote')

            for quote in quote_list:
                author = quote.find('small', class_='author').text
                author_url = quote.find('a', href=True)['href']
                if author_url not in author_urls:
                    author_urls.add(author_url)
                    
                    # Scrape author details from individual author page
                    author_response = requests.get(f'http://quotes.toscrape.com{author_url}')
                    author_soup = BeautifulSoup(author_response.text, 'html.parser')
                    name = author_soup.find('h3', class_='author-title').text
                    nationality = author_soup.find('span', class_='author-country').text if author_soup.find('span', class_='author-country') else 'Unknown'
                    description = author_soup.find('div', class_='author-description').text
                    date_of_birth = author_soup.find('span', class_='author-date-of-birth').text if author_soup.find('span', class_='author-date-of-birth') else 'Unknown'

                    authors.append({
                        'name': name,
                        'nationality': nationality,
                        'description': description,
                        'date_of_birth': date_of_birth
                    })
                    if len(authors) >= 20:  # Limit to 20 authors
                        return

    for page in range(1, num_pages + 1):
        scrape_page(page)
    
    return authors

# Base URL for the Quotes to Scrape site
quotes_base_url = 'http://quotes.toscrape.com/page/'
num_pages_quotes = 5
authors_data = scrape_authors(quotes_base_url, num_pages_quotes)
print("Authors Data:", authors_data)

# --- Scrape a Random Wikipedia Page ---

def scrape_random_wikipedia_page():
    random_wiki_url = 'https://en.wikipedia.org/wiki/Special:Random'
    response = requests.get(random_wiki_url)
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, 'html.parser')
        title = soup.find('h1', class_='firstHeading').text
        content = soup.find('div', class_='mw-parser-output').text.strip()

        return {
            'title': title,
            'content': content[:500]  # Limit content preview to 500 characters
        }
    return {}

# Run the Wikipedia scraper
random_wikipedia_page = scrape_random_wikipedia_page()
print("Random Wikipedia Page:", random_wikipedia_page)
